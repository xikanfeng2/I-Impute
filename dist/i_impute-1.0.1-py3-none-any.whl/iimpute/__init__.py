from .iimpute import IImpute
from .version import __version__

name = "i-impute"
